import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Dados {

    ArrayList<Infracao> listaInfracoes = new ArrayList<>();

    //metodo que carrega os dados para o sistema
    public void carregaDados(String nomeArquivo) throws IOException, ParseException {

        BufferedReader br = new BufferedReader(new FileReader(nomeArquivo));

        int nroLinha = 0;
        String linha = br.readLine();
        linha = br.readLine();
        String[] dados = new String[7];

        //loop para ler todas as linhas do arquivo
        while(linha != null){
            nroLinha++;
            //criar array para armazenar o conteudo da linha, separando as posicoes a partir do caractere ';'
            String[] aux = linha.split(";");

            int i = 0;
            //loop com try catch para solucionar uma exception de IndexOutOfBounds que ocorre quando alguma linha do arquivo
            //possui alguma coluna sem nenhum elemento
            try{
                while(i < 7){
                    dados[i] = aux[i];
                    i++;
                }
            }catch(IndexOutOfBoundsException e){
                dados[i] = "";
            }

            //armazenar as informacoes do array em variaveis
            String dataExtracao = dados[0];
            String bairro = dados[1];
            Date dataHoraInfracao = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS").parse(dados[2]);
            String enquadramento = dados[3];
            String penalidade = dados[4];

            //criar o objeto com as variaveis criadas
            Infracao infracao = new Infracao(dataExtracao, bairro, dataHoraInfracao, enquadramento, penalidade);

            //adicionar o objeto na arraylist
            listaInfracoes.add(infracao);

            //let a proxima linha
            linha = br.readLine();
        }
        //enviar a lista para a classe App, que utiliza ela para executar o programa
        App app = new App();
        app.recebeLista(listaInfracoes);

        br.close();
    }

}