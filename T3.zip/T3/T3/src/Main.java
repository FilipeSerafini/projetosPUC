import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        //criar um objeto da classe App para acessar o metodo executa, que inicia a execucao do programa
        App start = new App();
        start.executa();
    }
}