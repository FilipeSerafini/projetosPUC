import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class App {

    Dados dados = new Dados();
    private static ArrayList<Infracao> listaInfracoes = new ArrayList<>();

    //arraylist para armazenar os dados da ultima consulta realizada pelo usuario e ulitizar ele para salvar o arquivo
    ArrayList<Infracao> ultimaOperacao = new ArrayList<>();

    public App(){}

    //metodo para exibir o menu para o usuario
    private void exibeMenu(){
        System.out.println("\nDigite o numero que corresponde a acao desejada: ");
        System.out.println("0: Encerrar o programa.");
        System.out.println("1: Carregar arquivo de dados");
        System.out.println("2: Classificar dados por data.");
        System.out.println("3: Consultar todos os dados.");
        System.out.println("4: Consultar dados de uma determinada data.");
        System.out.println("5: Salvar os dados da consulta em arquivo.");
    }

    //metodo para executar o programa, chamando os metodos necessarios
    public void executa(){
        Scanner teclado = new Scanner(System.in);
        String acao;
        boolean encerraPrograma = false;

        //loop para permitir que o resto do programa apenas rode depois que o usuario carregue um arquivo
        boolean carregouDados = false;

        //loop para rodar o programa
        do{
            exibeMenu();
            acao = teclado.nextLine();
            switch(acao){
                case "0" -> {
                    System.out.println("Programa encerrado");
                    encerraPrograma = true;
                }
                case "1" -> carregouDados = carregaDados();
                case "2" -> {
                    if (carregouDados) classificaDadosData();
                    else System.out.println("Voce precisa carregar um arquivo de dados antes.");
                }
                case "3" -> {
                    if (carregouDados) consultaDados();
                    else System.out.println("Voce precisa carregar um arquivo de dados antes.");
                }
                case "4" -> {
                    if (carregouDados) consultaDadosDeterminadaData();
                    else System.out.println("Voce precisa carregar um arquivo de dados antes.");
                }
                case "5" ->{
                    if(carregouDados) {
                        try {
                            salvarDadosDeConsulta();
                        } catch (IOException e) {
                            System.out.println("Erro ao salvar arquivo.");
                        }
                    }
                    else System.out.println("Voce precisa carregar um arquivo de dados antes.");
                }
                default -> System.out.println("Valor digitado incorreto, tente novamente: ");
            }
        }while(!encerraPrograma);


    }

    //metodo para carregar os dados, retornando um boolean caso tenha tido sucesso ou nao
    private boolean carregaDados(){
        Scanner teclado = new Scanner(System.in);
        System.out.println("Digite o nome do arquivo de dados que deseja carregar: ");

        String nomeArquivo = teclado.nextLine();

        Dados dados = new Dados();
        try {
            //chamar o metedo que efetivamente carrega os dados, da classe Dados
            dados.carregaDados(nomeArquivo);
            System.out.println("Arquivo carregado com sucesso!");
            return true;

        }catch(IOException | ParseException e){
            System.out.println("Nao foi possivel encontrar um arquivo com o nome fornecido.");
            return false;
        }

    }

    //metodo para classificar os dados por data, de forma crescente ou decrescente
    private void classificaDadosData(){
        Scanner teclado = new Scanner(System.in);
        boolean valorValido = true;

        System.out.println("Com relacao a data: ");
        System.out.println("Digite 1 se voce deseja ver os dados em ordem CRESCENTE, ou 2 se voce deseja ver em ordem DECRESCENTE: ");

        //loop para o usuario selecionar qual opcao ele deseja realizar
        do {
            int acao = validaDigitacaoInt();
            switch (acao) {
                //caso 1: utiliza o metodo sort(), que recebe uma lista de objetos Infracao, que possuem
                //a interface Comparable e o metodo compareTo() implementados
                //esse case ordena a lista em ordem crescente de acordo com a data e printa na tela
                case 1 -> {
                    Collections.sort(listaInfracoes);
                    System.out.println(listaInfracoes);
                    valorValido = true;
                }
                //caso 2: realiza a mesma tarefa que o case 1, ordena a lista de forma crescente de acordo com a data
                //depois inverte a lista utilizando o metodo reverse() e printa na tela
                case 2 -> {
                    Collections.sort(listaInfracoes);
                    Collections.reverse(listaInfracoes);
                    System.out.println(listaInfracoes);
                    valorValido = true;
                }
                //caso o usuario tenha digitado algum valor diferente de 1 ou 2, volta para o loop e solicita novamente
                default -> {
                    System.out.println("Valor digitado incorreto. Tente novamente: ");
                    valorValido = false;
                }
            }
        }while(!valorValido);

        //atualiza o arraylist da ultima operacao com a lista atualizada
        ultimaOperacao = listaInfracoes;
    }

    //metodo para mostrar todos os dados na tela
    private void consultaDados(){
        System.out.println(listaInfracoes);
        ultimaOperacao = listaInfracoes;
    }

    //metodo para exibir na tela dados de uma determinada data
    private void consultaDadosDeterminadaData(){
        Scanner teclado = new Scanner(System.in);

        String dia, ano, mes;

        int diaInt = 1;
        int mesInt = 1;
        int anoInt = 1;
        System.out.println("Voce indicou que deseja pesquisar um dado a partir de uma determinada data.");

        //utilizar loops para garantir que o usuario digite os valores corretos
        do {
            System.out.println("Digite um dia valido: ");
            System.out.println("Se o numero for de apenas um digido, insira um 0 na frente.");
            dia = teclado.nextLine();
            try{
                diaInt = Integer.parseInt(dia);
            }catch(NumberFormatException e){
                System.out.println("Valor digitado invalido. Digite um numero");
                dia = "a"; //fazer o length da variavel dia ser diferente de 2 para voltar para o loop
            }
        }while(dia.length() != 2 || diaInt < 1 || diaInt > 31);
        do {
            System.out.println("Digite um mes valido: ");
            System.out.println("Se o numero for de apenas um digido, insira um 0 na frente.");
            mes = teclado.nextLine();
            try{
                mesInt = Integer.parseInt(mes);
            }catch(NumberFormatException e){
                System.out.println("Valor digitado invalido. Digite um numero");
                mes = "a"; //fazer o length da variavel dia ser diferente de 2 para voltar para o loop
            }
        }while(mes.length() != 2 || mesInt < 1 || mesInt > 12);
        do {
            System.out.println("Digite um ano valido: ");
            System.out.println("Escreva o numero do ano inteiro, utilizando os 4 digitos.");
            ano = teclado.nextLine();
            try{
                anoInt = Integer.parseInt(ano);
            }catch(NumberFormatException e){
                System.out.println("Valor digitado invalido. Digite um numero");
                ano = "a"; //fazer o length da variavel dia ser diferente de 4 para voltar para o loop
            }
        }while(ano.length() != 4);

        String dataUsuario = ano + "-" + mes + "-" + dia;

        //arraylist para guardar as informacoes de uma data especifica
        ArrayList<Infracao> infracoesDeUmaData = new ArrayList<>();

        //for iterado para passar por todos os elementos da lista e comparar a sua data com a data fornecida pelo usuario
        //e adicionar as que forem iguais em um arraylist separado
        for(Infracao inf : listaInfracoes){
            if(inf.formataData().equals(dataUsuario)){
                infracoesDeUmaData.add(inf);
            }
        }

        //verificar se o arraylist criado possui algum dado, se nao tiver nenhum significa que nao foi encontrada
        //nenhuma infracao que possua a mesma data que o usuario forneceu
        if(!infracoesDeUmaData.isEmpty())
            System.out.println(infracoesDeUmaData);
        else
            System.out.println("Nao foram encontrados dados para a data desejada.");

        //atualizar o arraylist da ultima operacao com os dados encontrados (ou nao) de uma determinada data
        ultimaOperacao = infracoesDeUmaData;
    }

    //metodo para salvar os dados da ultima consulta do usuario em um arquivo
    private void salvarDadosDeConsulta() throws IOException{
        Scanner teclado = new Scanner(System.in);
        System.out.println("Digite o nome do arquivo que deseja salvar: ");
        String nomeArquivo = teclado.nextLine();

        //criar um string builder e realizar um for iterado que concatena todas as informacoes possuidas da ultima consulta
        //realizada pelo usuario em uma unica string, separadas por ; formando um arquivo CSV
        StringBuilder texto  = new StringBuilder();
        for(Infracao inf: ultimaOperacao){
            texto.append(inf.toCsv());
        }

        //criar o arquivo e escrever nele a string que possui as informacoes da ultima consulta realizada pelo usuario
        FileWriter criadorArquivo = new FileWriter(nomeArquivo + ".csv");
        BufferedWriter bw = new BufferedWriter(criadorArquivo);
        PrintWriter escritor = new PrintWriter(bw);

        escritor.append(texto);
        bw.close();;
        System.out.println("Arquivo criado com sucesso!");
    }

    //metodo para receber a lista de infracoes da classe Dados
    public void recebeLista(ArrayList<Infracao> listaInf){
        listaInfracoes = listaInf;
    }

    //metodo para garantir que o usuario digite um int quando necessario
    private int validaDigitacaoInt() {
        Scanner teclado = new Scanner(System.in);

        int numero = 0;
        boolean isNumber;

        //garantir que seja digitado um numero
        do {
            isNumber = true;
            try{
                numero = teclado.nextInt();
            }catch(Exception e){
                System.out.println("Valor digitado incorreto. Digite um numero valido.");
                isNumber = false;
                teclado.next();
            }

        } while (!isNumber);
        return numero;
    }
}