import java.text.SimpleDateFormat;
import java.util.Date;

public class Infracao implements Comparable<Infracao>{

    //criacao de todas as variaveis necessarias
    private String dataExtracao;
    private String bairro;
    private Date dataHoraInfracao;
    private String enquadramento;
    private String penalidade;


    //construtor
    public Infracao(String dataExtracao, String bairro, Date dataHoraInfracao, String enquadramento, String penalidade) {
        this.dataExtracao = dataExtracao;
        this.bairro = bairro;
        this.dataHoraInfracao = dataHoraInfracao;
        this.enquadramento = enquadramento;
        this.penalidade = penalidade;
    }

    //metodo compareTo criado devido a implementacao da interface Comparable
    @Override
    public int compareTo(Infracao o) {
        return getDataHoraInfracao().compareTo(o.getDataHoraInfracao());
    }

    //metodo toString
    @Override
    public String toString() {
        return "Infracao -> " +
                "Data Extracao: '" + dataExtracao + '\'' +
                ", Bairro: '" + bairro + '\'' +
                ", Data e Hora Infracao: '" + dataHoraInfracao + '\'' +
                ", Enquadramento: '" + enquadramento + '\'' +
                ", Penalidade: '" + penalidade + '\'' + "\n" +
                '}';
    }

    //metodo para formatar a data removendo o horario, deixando apenas ano mes e dia
    public String formataData(){
        SimpleDateFormat formatacao = new SimpleDateFormat("yyyy-MM-dd");
        return formatacao.format(dataHoraInfracao);
    }

    //metodo para formatar a string de informacoes em formato CSV
    public String toCsv(){
        return "DataExtracao: " + dataExtracao + ";" + "Bairro: " + bairro + ";" + "DataInfracao: " + dataHoraInfracao + ";" + "Enquadramento: " + enquadramento + ";" + "Penalidade: " + penalidade + ";\n";
    }

    public Date getDataHoraInfracao() {
        return dataHoraInfracao;
    }
}