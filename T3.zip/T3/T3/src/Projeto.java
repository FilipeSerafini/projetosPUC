import java.util.Date;

public class Projeto implements Comparable<Projeto>{

    String dataExtracao;
    String numero;
    String areaPrivativa;
    Date dataProjeto;
    String tipoProjeto;
    String areaTotalAConstruir;
    String descricaoAtividade;

    public Projeto(String dataExtracao, String numero, String areaPrivativa, Date dataProjeto, String tipoProjeto, String areaTotalAConstruir, String descricaoAtividade) {
        this.dataExtracao = dataExtracao;
        this.numero = numero;
        this.areaPrivativa = areaPrivativa;
        this.dataProjeto = dataProjeto;
        this.tipoProjeto = tipoProjeto;
        this.areaTotalAConstruir = areaTotalAConstruir;
        this.descricaoAtividade = descricaoAtividade;
    }


    public int compareTo(Projeto p) {
        return getDataProjeto().compareTo(p.getDataProjeto());
    }

    @Override
    public String toString() {
        return "Projeto{" +
                "dataExtracao='" + dataExtracao + '\'' +
                ", numero='" + numero + '\'' +
                ", areaPrivativa='" + areaPrivativa + '\'' +
                ", dataProjeto=" + dataProjeto +
                ", tipoProjeto='" + tipoProjeto + '\'' +
                ", areaTotalAConstruir='" + areaTotalAConstruir + '\'' +
                ", descricaoAtividade='" + descricaoAtividade + '\'' + "\n" +
                '}';
    }

    public String getDataExtracao() {
        return dataExtracao;
    }

    public String getNumero() {
        return numero;
    }

    public String getAreaPrivativa() {
        return areaPrivativa;
    }

    public Date getDataProjeto() {
        return dataProjeto;
    }

    public String getTipoProjeto() {
        return tipoProjeto;
    }

    public String getAreaTotalAConstruir() {
        return areaTotalAConstruir;
    }

    public String getDescricaoAtividade() {
        return descricaoAtividade;
    }

}
