package ACMEFinancas;

public class Cadastro {

	private Cobravel[] cobraveis;

	public boolean adiciona(Cobravel item) {
		return false;
	}

	public Cobravel[] pesquisa(String nome) {
		return null;
	}

	public Cobravel[] pesquisa() {
		return null;
	}

	public double calculaImpostoItem(int identificador) {
		return 0;
	}

	public void salvaArquivoTexto(String nomeArquivo) {

	}

}
