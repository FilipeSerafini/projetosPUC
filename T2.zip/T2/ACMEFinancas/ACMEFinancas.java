package ACMEFinancas;

public class ACMEFinancas {

	private Cadastro cadastro;

	public void inicializa() {

	}

	public void executa() {

	}

}
