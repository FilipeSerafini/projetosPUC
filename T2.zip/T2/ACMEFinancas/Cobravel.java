package ACMEFinancas;

public abstract class Cobravel {

	protected int identificador;

	protected String nome;

	protected double valorBase;

	public Cobravel(int identificador, String nome, double valorBase) {

	}

	public abstract double calculaImposto();

	public abstract String toCsv();

}
